
public class RequeteAuthorisationTO
{

    public RequeteAuthorisationTO()
    {
    }

    public String getApi_key()
    {
        return api_key;
    }

    public void setApi_key(String api_key)
    {
        this.api_key = api_key;
    }

    public int getStore_id()
    {
        return store_id;
    }

    public void setStore_id(int store_id)
    {
        this.store_id = store_id;
    }

    public long getTransaction_id()
    {
        return transaction_id;
    }

    public void setTransaction_id(long transaction_id)
    {
        this.transaction_id = transaction_id;
    }

    private String api_key;
    private int store_id;
    private long transaction_id;
}

