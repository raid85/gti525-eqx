import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import sun.net.www.protocol.http.HttpURLConnection;


public class PaiementDAO implements IPaiementDAO{

	private String baseUrl = "http://gti525.heroku.com/transactions";
	
	
	
	@Override
	public ReponseSystemePaiementTO approuverTransaction(RequeteAuthorisationTO requeteAutorisationTO) {
		ReponseSystemePaiementTO reponse = new ReponseSystemePaiementTO();
        URL url = null;
        String link = baseUrl + "/"+requeteAutorisationTO.getTransaction_id()+".json?" +
				"api_key="		+ requeteAutorisationTO.getApi_key() 		+ 	
				"&store_id=" 	+ requeteAutorisationTO.getStore_id()		;
        System.out.println(link);
				
		try {
				url = new URL(link);
		        URLConnection conn = url.openConnection();
		        ((HttpURLConnection) conn).setRequestMethod("GET");
		        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		       
		        String jsonString="";
		        String line; while ((line = in.readLine()) != null) {
		            jsonString += line;
		        }
		        JSONObject json = (JSONObject) JSONSerializer.toJSON( jsonString );
		        JSONObject jsonObject = (JSONObject) json;
		        
		        JSONObject baseNode = jsonObject.getJSONObject("order");
		        String status = (String) baseNode.get("status");
		        if (status.equals("Completed")) {
	            	reponse.setMessage((String) baseNode.get("messages"));	            	
			        reponse.setCode((Integer) baseNode.get("code"));
			        reponse.setTransactionId((Integer) baseNode.get("transaction_id"));
			        reponse.setStatus((String) baseNode.get("status"));
	            }
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reponse;	
	}

	@Override
	public ReponseSystemePaiementTO effectuerPreauthorisation(InformationsPaiementTO informationPaiementTO) {
		ReponseSystemePaiementTO reponse = new ReponseSystemePaiementTO();
        URL url = null;
        String link = baseUrl + ".json?" +
				"api_key="		+ informationPaiementTO.getApi_key() 		+ 	
				"&order_id="		+ informationPaiementTO.getOrder_id() 	+ 	
				"&store_id=" 	+ informationPaiementTO.getStore_id()		+
				"&amount="		+ informationPaiementTO.getAmount()			+
				"&first_name="	+ informationPaiementTO.getFirst_name()		+ 
				"&last_name="	+ informationPaiementTO.getLast_name()		+
				"&card_number="	+ informationPaiementTO.getCard_number()	+
				"&security_code="+ informationPaiementTO.getSecurity_code()	+
				"&year="			+ informationPaiementTO.getYear()		+
				"&month="		+ informationPaiementTO.getMonth();
		try {
				url = new URL(link);
		        URLConnection conn = url.openConnection();
		        ((HttpURLConnection) conn).setRequestMethod("POST");
		        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		       
		        String jsonString="";
		        String line; while ((line = in.readLine()) != null) {
		            jsonString += line;
		        }
		        JSONObject json = (JSONObject) JSONSerializer.toJSON( jsonString );
		        JSONObject jsonObject = (JSONObject) json;
		        
		        JSONObject baseNode = jsonObject.getJSONObject("order");
		        String status = (String) baseNode.get("status");
		        if (status.equals("Accepted")) {
	            	reponse.setMessage((String) baseNode.get("messages"));	            	
			        reponse.setCode((Integer) baseNode.get("code"));
			        reponse.setTransactionId((Integer) baseNode.get("transaction_id"));
			        reponse.setStatus((String) baseNode.get("status"));
	            }
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reponse;
	}
	
	

	
	

}
