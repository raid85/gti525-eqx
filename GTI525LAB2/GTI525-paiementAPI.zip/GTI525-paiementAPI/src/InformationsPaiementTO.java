import java.math.BigDecimal;


public class InformationsPaiementTO
{

    public InformationsPaiementTO()
    {
    }

    public String getApi_key()
    {
        return api_key;
    }

    public void setApi_key(String api_key)
    {
        this.api_key = api_key;
    }

    public int getStore_id()
    {
        return store_id;
    }

    public void setStore_id(int store_id)
    {
        this.store_id = store_id;
    }

    public long getOrder_id()
    {
        return order_id;
    }

    public void setOrder_id(long order_id)
    {
        this.order_id = order_id;
    }

    public String getFirst_name()
    {
        return first_name;
    }

    public void setFirst_name(String first_name)
    {
        this.first_name = first_name;
    }

    public String getLast_name()
    {
        return last_name;
    }

    public void setLast_name(String last_name)
    {
        this.last_name = last_name;
    }

    public long getCard_number()
    {
        return card_number;
    }

    public void setCard_number(long card_number)
    {
        this.card_number = card_number;
    }

    public int getSecurity_code()
    {
        return security_code;
    }

    public void setSecurity_code(int security_code)
    {
        this.security_code = security_code;
    }

    public int getYear()
    {
        return year;
    }

    public void setYear(int year)
    {
        this.year = year;
    }

    public int getMonth()
    {
        return month;
    }

    public void setMonth(int month)
    {
        this.month = month;
    }

    public BigDecimal getAmount()
    {
        return amount;
    }

    public void setAmount(BigDecimal amount)
    {
        this.amount = amount;
    }

    private String api_key;
    private int store_id;
    private long order_id;
    private String first_name;
    private String last_name;
    private long card_number;
    private int security_code;
    private int year;
    private int month;
    private BigDecimal amount;
}


