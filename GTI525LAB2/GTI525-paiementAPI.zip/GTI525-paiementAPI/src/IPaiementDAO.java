
public interface IPaiementDAO{
    public abstract ReponseSystemePaiementTO effectuerPreauthorisation(InformationsPaiementTO informationspaiementto);
    public abstract ReponseSystemePaiementTO approuverTransaction(RequeteAuthorisationTO requeteauthorisationto);
}
